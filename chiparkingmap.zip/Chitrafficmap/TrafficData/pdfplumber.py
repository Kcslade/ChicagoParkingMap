import pdfplumber as pdfp
import pandas as pd

# Open the PDF file
with pdfp.open(r"C:\Users\hambu\Desktop\Chitrafficmap\parking Data\Schedule_10.pdf") as pdf:
    # Initialize a list to hold the data
    data = []

    # Loop through each page in the PDF
    for page in pdf.pages:
        # Extract the table from the page
        table = page.extract_table()
        if table:
            data.extend(table)

# Convert the data to a DataFrame
df = pd.DataFrame(data[1:], columns=data[0])

# Save the DataFrame to a CSV file
df.to_csv(r"C:\Users\hambu\Desktop\Chitrafficmap\parking Data\Schedule_10.csv", index=False)
