import pandas as pd
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut

# Load your CSV file into a DataFrame
df = pd.read_csv(r"C:\Users\hambu\Desktop\Chitrafficmap\parking Data\Schedule_10.xlsx - Sheet1.csv")

# Initialize the geocoder
geolocator = Nominatim(user_agent="chistreetmap")

# Function to geocode an address
def geocode_address(address):
    try:
        location = geolocator.geocode(address)
        if location:
            return location.latitude, location.longitude
        else:
            return None, None
    except GeocoderTimedOut:
        return geocode_address(address)

# Apply the geocoding function to your DataFrame
df['latitude'], df['longitude'] = zip(*df['address'].apply(geocode_address))

# Save the results to a new CSV file
df.to_csv(r"C:\Users\hambu\Desktop\Chitrafficmap\parking Data\Schedule_10geocoded_addresses.csv", index=False)
